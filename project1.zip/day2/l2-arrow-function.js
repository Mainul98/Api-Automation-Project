function my_print() {
    console.log("hello world");
    // function my_print(){
    //     console.log("hello world");
    //     function my_print(){
    //         console.log("hello world");
    //     }
    //     function my_print(){
    //         console.log("hello world");
    //     }
    // }
}



// arrow sign : (without space) = >  [=>]
// rule to convert normal function to arrow function
// rule 1 - put equal after function name
// rule 2 - put arrow after parantheses ()
// rule 3 - finish the function with curly brace {}
my_print2 = () => {
    console.log("hello world 2");
}

my_print();
my_print2();

// variable priority : string has more priority over int
// find the output 
// let  e = "2"
// let  f = 2
// let g = e + f
// console.log(g)
// option :
// 1) 22
// 2) 4
// 3) Type error
// 4) "22"
// 5) none of these above

// 2+ "2"+2+"2"= "2222" = 2222 / 8

function my_add(a, b) {
    const result = Number(a) + Number(b);
    console.log("result is : " + result);
}

// tech: automatic door
// scenario: block an employee - id = 207
//
// plan
// 1. allow all
// 2. block 207

// plan
// 1. block
// 2. allow all