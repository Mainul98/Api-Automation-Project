// JIT = Just in time compilation
// let y = 1
// let z = 0
// let x = y / z
// try{
// }catch(Excepton e){
//     console.log("you have eneterned 0/ please correct number");
// }

// add - person
// function s() {

// }

// s();

// delete - person


// let d = 2
// d = "2"

function s2(name, age) {
    console.log("my age is: " + age)
    console.log("my age is: " + Number(age))
    console.log("my name is: " + name)
}

// s2();
// s2('bob', 30);
// s2("bob", 30);
// s2(`bob`, 30);


// function getPersonNameByIdandMobileNumber() {
//     console.log("hello everyone");
// }

// getPersonNameByIdandMobileNumber();

// const getPerson = getPersonNameByIdandMobileNumber();

// getPerson;

function getPersonNameByIdandMobileNumber2(name) {
    console.log("hello " + name);
}

// getPersonNameByIdandMobileNumber2();

const getPerson2 = getPersonNameByIdandMobileNumber2("zafir");

// getPerson2;
// s1();
function s3() {
    return "Hello world";
}
// console.log(s3());
const x = s3();
// console.log(x);
const x2 = s3;
// console.log(x2());

// s2("alex", 20);
// const x = s3();
// console.log(x);
// console.log(s3());

// x= 2
// x= "2"
// x= {name: "silvy"}

// const x2 = s1
// console.log(x2())

// function abc2(a,b){}
// const aa = x2()
// const bb = x2()
// abc2(aa, bb)

// function abc(a,b){}
// abc(x2(),x2())

// function abc(a,b){}
// abc(aa,bb)

// = >
// =>

