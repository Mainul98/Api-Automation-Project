let my_array;

// console.log("array 0: " + my_array);

let my_array2 = undefined;

// console.log("array 00: " + my_array);

let my_array3 = null;

// console.log("array 01: " + my_array3);

const items = [];

// console.log("array 1: " + items);

// style="color: red"
const x = [1,2,3];

// console.log("array 2: " + x);

// const x: int[] 
items.push(10); //0
items.push(40); //1

console.log("array 3: " + items);
// items.push(30); //2
// items.push(100); //3

// 0 2
// for (i = 0; i < items.length; i=i+2) {

// 1

// 1000

// +5

// 1000

// 1

// -5

// for (i = 0; i < items.length; i++) {
//     console.log("by for loop: " + items[i]);
// }

// !5 = 5*4*3*2*1

// let multiplicationResult = 1;
// for (i = 5; i > 0; i--) {
//     multiplicationResult = multiplicationResult * i;
// }
// console.log("my result is: " + multiplicationResult);

// j = 0;
// while (j < items.length) {
//     console.log("by while loop: " + items[j]);
//     j++;
// }

// for (i = 0; i < items.length; i++) {
//     if (items[i] < 100) {
//         console.log(items[i]);
//     }
// }

// for (const item of items) {
//     console.log(item);
// }

// for (let item of items) {
//     console.log(item);
//     // items.indexOf(2)
// }


// for (const item of items) {
//     if (item < 100) {
//         item += 1
//         console.log(item);
//     }
// }
// if (item < 100) {
//     item += 1
//     console.log(item);
// }

// for (let item of items) {
//     console.log(item);
// }