// let student = {
//     name: "jhon",
//     age: 20,
//     marks: 69.89
// };

// let x = 1;
// let y = "2";
// let a = 1;
// let z = x + y + a;
// let z1 = Number(x) + Number(y) + Number(a);
// console.log(a);
// console.log(z);
// console.log(z1);

// q: find the output
// 1: 3
// 2: type error
// 3: 12
// 4: "12"
// 5: "3"
// 6: "none of the above"

// let student = {
//     "name": null,
//     "age": undefined,
//     "roll": "A"
// };
// console.log(student)
// student.name = "alex"
// console.log(student)
// student.phoneNumber = "222"
// console.log(student)

// let student2 = {
//     "name": null,
//     "age": undefined,
//     "roll": "A"
// };


// const people = {
//     name: "alex",
//     age: 2,
//     salary: 30.5,
//     phones: ["123", "456"],
//     address: {
//         city: "Dhaka",
//         country: "Bangladesh"
//     }
// };

// console.log(people);

let people2 = {
    name: null,
    age: null,
    salary: null,
    phones: null,
    address: null
};

people2.name = "alex";
people2.age = 30;
people2.salary = 10000.5;
people2.phones = [ '017', '018' ];
my_address = {
    city: "Dhaka",
    zip: 1209,
    street: "Mohammadpur",
    country: "Bangladesh"
};
people2.address = my_address;


// people.name = "mr. alex";
// people.age += 1;
// people.job = "teacher";
// console.log(people);

// people = {
//     car: "bmw"
// }
// console.log(people);
