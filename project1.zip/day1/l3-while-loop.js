const items = [];
items.push(10); //0
items.push(40); //1
items.push(30); //2
items.push(100); //3


i = 0;
while (i < items.length) {
    console.log(items[i]);
    i++;
}

