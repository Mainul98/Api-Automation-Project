
var x;
x = "hello world";
x = "hello world 2";
console.log(x);
// var x = "hello world";
// var x = "hello world";
// var x = "hello world";\
let y;
y = "hello world";
y = "hello world 2";
console.log(y);
// let x = "hello world";
// let x = "hello world";
// just in time compilation (JIT)
// const x = "hello world";
// const z;
const z = 2;
console.log(z);
z = 3;
console.log(z);

// console.log(x);

// let y = 1;
// console.log(y);

// const z = 1;
// console.log(z);

// const g;

// let l;
// console.log(l);

// let k;
// let k = 2;
// console.log(k);
// console.log(typeof(k));

// let d = 2;
// d = undefined;
// console.log(d);

// let s = 2;
// s = null;
// console.log(s);

// let k = {}
// let k2 = {
//     name: 'bob',
//     age: 22
// }
// let m = undefined