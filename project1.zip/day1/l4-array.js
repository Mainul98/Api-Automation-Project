const items = []
items.push(10)
items.push(40)
items.push(30)
items.push(100)
console.log(items);

const items2 = [10, 20, 30, 40]
console.log(items2);